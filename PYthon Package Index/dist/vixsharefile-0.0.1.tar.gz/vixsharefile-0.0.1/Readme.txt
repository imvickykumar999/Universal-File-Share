
'This package has File Sharing functions.'

# Usage :

`from vixsharefile import run_server`
