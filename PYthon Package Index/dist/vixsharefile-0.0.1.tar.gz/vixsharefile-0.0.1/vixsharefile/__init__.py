
available_functions = '''

Try running below line to start sharing.

from sharefile import run_server

'''

print(available_functions)
